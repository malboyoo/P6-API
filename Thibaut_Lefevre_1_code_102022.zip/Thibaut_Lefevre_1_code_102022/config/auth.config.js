module.exports = {
  secret: "openclassroom-secret-key",
};
