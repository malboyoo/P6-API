module.exports = {
  USER: "Malbo",
  ADDRESS: "cluster0.xuzjnbm.mongodb.net",
  DB: "hottakes",
  PWD: "admin123",
};
